#!/bin/bash

sudo python3 /home/pi/Desktop/camPlot.py